#Load packages
if (require(knitr) == F) {
  install.packages("knitr")
}
if (require(rmarkdown) == F) {
  install.packages("rmarkdown")
}
if (require(car) == F) {
  install.packages("car")
}
if (require(stats) == F) {
  install.packages("stats")
}
if (require(gridExtra) == F) {
  install.packages("gridExtra")
}
if (require(ggplot2) == F) {
  install.packages("ggplot2")
}
if (require(effsize) == F) {
  install.packages("effsize")
}
if (require(vcd) == F) {
  install.packages("vcd")
}
if (require(gmodels) == F) {
  install.packages("gmodels")
}
if (require(epitools) == F) {
  install.packages("epitools")
}
if (require(ACSWR) == F) {
  install.packages("ACSWR")
}
if (require(MASS) == F) {
  install.packages(MASS)
}
if (require(caret) == F) {
  install.packages("caret")
}
if (require(RobStatTM) == F) {
  install.packages("RobStatTM")
}
if (require(glmnet) == F) {
  install.packages("glmnet")
}
if (require(readr) == F) {
  install.packages("readr")
}
if (require(pROC) == F) {
  install.packages("pROC")
}
if (require(rpart) == F) {
  install.packages("rpart")
}
if (require(aod) == F) {
  install.packages("aod")
}
if (require(rpart.plot) == F) {
  install.packages("rpart.plot")
}
if (require(ranger) == F) {
  install.packages("ranger")
}
if (require(vip) == F) {
  install.packages("vip")
}
if (require(xgboost) == F) {
  install.packages("xgboost")
}
if (require(Matrix) == F) {
  install.packages("Matrix")
}
if (require(dplyr) == F) {
  install.packages("dplyr")
}
library(xgboost)
library(Matrix)
library(vip)
library(ranger)
library(rpart.plot)
library(rpart)
library(aod)
library(rpart)
library(pROC)
library(readr)
library(rmarkdown)
library(knitr)
library(MASS)
library(moments)
library(car)
library(stats)
library(gridExtra)
library(ggplot2)
library(effsize)
library(vcd)
library(gmodels)
library(epitools)
library(ACSWR)
library(caret)
library(RobStatTM)
library(glmnet)


# Prepare Data
set.seed(123457)
# Load Data
setwd("C:/Users/admin/Desktop/Grad_School/STAT5405/Final_Project")
df <- read_csv("project.csv", show_col_types = FALSE)
#df$TOVER <- as.factor(df$TOVER)
df$LEGAL <- as.factor(df$LEGAL)
df$ASTR <- as.factor(df$ASTR)
df$OSTR <- as.factor(df$OSTR)
df$CHR <- as.factor(df$CHR)
df$THIRD <- as.factor(df$THIRD)

# Visualize predictor variables

# Distribution of ASTR
spinetable <- table(df$ASTR)
barplot(spinetable, 
        main = "Distribution of ASSET", 
        col = c("lightgreen"), xlab = "Total Book Value of Assets",
        ylab = "Relative Frequency")
# Visualize Response Variables

# Distribution of BIDNUM


# Train and test data sets split into 80/20 proportion.
train.prop <- 0.80
trnset <- sort(sample(1:nrow(df), ceiling(nrow(df)*train.prop)))
# create the training and test sets
train.set <- df[trnset, ]
test.set  <- df[-trnset, ]

# Distribution of Response Variable: BIDNUM
hist(df$BIDNUM, 
     main = "Frequency of BIDNUM in data", 
     col = c("pink"), xlab = "# of bids recieved",
     ylab = "Relative Frequency")


# Poisson LogLinear Model
# Fitted Full model
bidnum.pf <- glm(BIDNUM ~ ., family = 'poisson', data = train.set)
summary(bidnum.pf)

# Dispersion Parameter of Fitted Full Model
disp.est <- bidnum.pf$deviance / bidnum.pf$df.residual

# Null Model
bidnum.pn <- glm(BIDNUM ~ 1, family = 'poisson', data = train.set)
summary(bidnum.pn)

# Compare Fitted Full to Null
an1 <- anova(bidnum.pn, bidnum.pf, test = "Chisq")
an1$`Pr(>Chi)`[2] # recover the same p-value

# Compare Fitted Full to Saturated model
with(bidnum.pf, cbind(deviance = deviance, df = df.residual,
                      p = pchisq(deviance, df.residual, lower.tail = FALSE)))

# Reduced Model
bidnum.pr <- glm(BIDNUM ~ train.set$ASSET + train.set$LEGAL + train.set$THIRD, family = 'poisson', data = train.set)
summary(bidnum.pr)

# Compare Reduced to Fitted Full
an <- anova(bidnum.pr, bidnum.pf, test = "Chisq")
an$`Pr(>Chi)`[2] # recover the same p-value

# Accuracy of Reduced model using MAE (Mean Absolute Error)
pred.full <- predict(bidnum.pr, newdata = test.set, type = "response")
summary(pred.full)
mean(abs(test.set$BIDNUM - pred.full))

#Negative Binomial Model
# Fitted Full model
bidnum.nbf <-glm.nb(BIDNUM ~ ., data = train.set)
summary(bidnum.nbf)

# Null Model
bidnum.nbn <-glm.nb(BIDNUM ~ 1, data = train.set)
summary(bidnum.nbn)

# Compare Fitted Full and Null models
(an.nb <- anova(bidnum.nbn, bidnum.nbf, test = "Chisq"))

# Refining Model
bidnum.nbr <-glm.nb(BIDNUM ~ train.set$ASSET + train.set$LEGAL + train.set$THIRD, data = train.set)
summary(bidnum.nbr)

# Compare Fitted Full and Reduced Model
(an.nb <- anova(bidnum.nbr, bidnum.nbf, test = "Chisq"))

# Residual Diagnostics
bidnum.nbr.res <- resid(bidnum.nbr, type = "deviance") 
car::qqPlot(bidnum.nbr.res)
shapiro.test(bidnum.nbr.res)

# Accuracy of Model (MAE)
pred.full <- predict(bidnum.nbr, newdata = test.set, type = "response")
summary(pred.full)
mean(abs(test.set$BIDNUM - pred.full))

# Preparing data for Binary response

# Prepare Data
# Define Response Variable
df$biry <- ifelse(df$BIDNUM < 2, 0, 1)

# Convert to Factor
df$biry <- as.factor(df$biry)

# Remove BIDNUM from dataset 
df <- df[,-3]

#Logit Model


# Training and Testing data sets
set.seed(123457)
train.prop <- 0.80
strats <- df$biry
rr <- split(1:length(strats), strats)
idx <- sort(as.numeric(unlist(sapply(rr, 
                                     function(x) sample(x, length(x)*train.prop)))))
df.train <- df[idx, ]
df.test <- df[-idx, ]

# Check proportions of response variable in both data sets
summary(df$biry)/nrow(df)
summary(df.train$biry)/nrow(df.train)
summary(df.test$biry)/nrow(df.test)

# Fitting the Full logit
full.logit <- glm(df.train$biry ~ . ,data = df.train, 
                  family = binomial(link = "logit"))
summary(full.logit)

# Fitting the Null model
null.logit <- glm(df.train$biry ~ 1 ,data = df.train, 
                  family = binomial(link = "logit"))
summary(null.logit)

# Fitting the Reduced Model
both.logit <- step(null.logit, list(lower = formula(null.logit),
                                    upper = formula(full.logit)),
                   direction = "both", trace = 0, data = df.train)
formula(both.logit)
summary(both.logit)

# Compare reduced and full model
(an.nb <- anova(both.logit, full.logit, test = "Chisq"))

# Compare full and null
(an.nb <- anova(null.logit, full.logit, test = "Chisq"))

# Accuracy of reduced model on testing data 

# Testing dataset
pred.null <- predict(both.logit, newdata = df.test, type = "response")
summary(pred.null)
# Confusion Matrices
table.null <- table(pred.null > 0.5, df.test$biry)
table.null
# Accuracy of model
(accuracy.null <- round((sum(diag(table.null))/sum(table.null))*100, 3))
cat("\n")
# Sensitivity (Positive Class)
b <- ifelse(pred.null == 1, 1, 0) # convert predicted probability to binary level
cm.null <- confusionMatrix(reference = as.factor(df.test$biry), 
                           data = as.factor(b), mode = "everything")
cm.null
# AOC Curves of models on testing dataset
roc.null <- roc(df.test$biry ~ pred.null, plot = TRUE, 
                legacy.axes = TRUE, print.auc = TRUE, main = "Accuracy of Reduced Model on Testing Data")

# Model with interactions
variables <- colnames(df)
interaction.var <-
  combn(variables, 2,
        FUN = function(x)
          paste(x, collapse = ":")
  )
formula.inter <-
  as.formula(paste("biry ~ . +", paste(interaction.var, collapse = "+")))
all.logit <- glm(formula = formula.inter,
                 family = binomial(link = "logit"),
                 data = df.train)
summary(all.logit)

# Accuracy of reduced model with interactions on testing data 

# Testing dataset
pred.null <- predict(all.logit, newdata = df.test, type = "response")
summary(pred.null)
# Confusion Matrices
table.null <- table(pred.null > 0.5, df.test$biry)
table.null
# Accuracy of model
(accuracy.null <- round((sum(diag(table.null))/sum(table.null))*100, 3))
cat("\n")
# Sensitivity (Positive Class)
b <- ifelse(pred.null == 1, 1, 0) # convert predicted probability to binary level
cm.null <- confusionMatrix(reference = as.factor(df.test$biry), 
                           data = as.factor(b), mode = "everything")
cm.null
# AOC Curves of models on testing dataset
roc.null <- roc(df.test$biry ~ pred.null, plot = TRUE, 
                legacy.axes = TRUE, print.auc = TRUE, main = "Accuracy of Reduced Model With Interactions on Testing Data")

# Full probit model
full.probit <- glm(df.train$biry ~ . ,data = df.train , 
                   family = binomial(link = "probit"))
summary(full.probit)

# Null probit model
null.probit <- glm(df.train$biry ~ 1 ,data = df.train , 
                   family = binomial(link = "probit"))
summary(null.probit)

# Compare full and null models
(an.nb <- anova(null.probit, full.probit, test = "Chisq"))

# Reduced probit model
# Fitting the Reduced Model
both.probit <- step(null.probit, list(lower = formula(null.probit),
                                      upper = formula(full.probit)),
                    direction = "both", trace = 0, data = df.train)
formula(both.probit)
summary(both.probit)

# Compare full and reduced models
(an.nb <- anova(both.probit, full.probit, test = "Chisq"))

# Accuracy of reduced model on testing data 

# Testing dataset
pred.null <- predict(both.probit, newdata = df.test, type = "response")
summary(pred.null)
# Confusion Matrices
table.null <- table(pred.null > 0.5, df.test$biry)
table.null
# Accuracy of model
(accuracy.null <- round((sum(diag(table.null))/sum(table.null))*100, 3))
cat("\n")
# Sensitivity (Positive Class)
b <- ifelse(pred.null == 1, 1, 0) # convert predicted probability to binary level
cm.null <- confusionMatrix(reference = as.factor(df.test$biry), 
                           data = as.factor(b), mode = "everything")
cm.null
# AOC Curves of models on testing dataset
roc.null <- roc(df.test$biry ~ pred.null, plot = TRUE, 
                legacy.axes = TRUE, print.auc = TRUE, main = "Accuracy of Reduced Model on Testing Data")

# Model with interactions
variables <- colnames(df)
interaction.var <-
  combn(variables, 2,
        FUN = function(x)
          paste(x, collapse = ":")
  )
formula.inter <-
  as.formula(paste("biry ~ . +", paste(interaction.var, collapse = "+")))
all.probit <- glm(formula = formula.inter,
                  family = binomial(link = "probit"),
                  data = df.train)
summary(all.probit)


# Accuracy of reduced model with interactions on testing data 

# Testing dataset
pred.null <- predict(all.probit, newdata = df.test, type = "response")
summary(pred.null)
# Confusion Matrices
table.null <- table(pred.null > 0.5, df.test$biry)
table.null
# Accuracy of model
(accuracy.null <- round((sum(diag(table.null))/sum(table.null))*100, 3))
cat("\n")
# Sensitivity (Positive Class)
b <- ifelse(pred.null == 1, 1, 0) # convert predicted probability to binary level
cm.null <- confusionMatrix(reference = as.factor(df.test$biry), 
                           data = as.factor(b), mode = "everything")
cm.null
# AOC Curves of models on testing dataset
roc.null <- roc(df.test$biry ~ pred.null, plot = TRUE, 
                legacy.axes = TRUE, print.auc = TRUE, main = "Accuracy of Reduced Model on Testing Data")


# CART Approach
# Grow tree using all predictors
df$ID <- as.factor(df$ID)
fit.allp <- rpart(df.train$biry ~., method = "class", data = df.train,
                  control = rpart.control(minsplit = 1, cp = 0.0001))

# Root Node Error
(rootnode_err <- sum(df.train$Kyphosis=="1")/nrow(df.train))

# Print Output from rpart()
printcp(fit.allp) 

# What value of CP is xerror smallest?
(cp <- fit.allp$cptable[which.min(fit.allp$cptable[, "xerror"]), "CP"])
(xerr <- fit.allp$cptable[which.min(fit.allp$cptable[, "xerror"]), "xerror"])
(nsplit <- fit.allp$cptable[which.min(fit.allp$cptable[, "xerror"]), "nsplit"])
#(xstd <- fit.allp$cptable[which.min(fit.allp$cptable[, "xerror"]), "xstd"])

# Plot of Xerror vs CP values
plotcp(fit.allp)
rpart.plot(fit.allp, extra = "auto")

# Convert test data to dataframe
test_df <- data.frame(actual = df.test$biry, pred = NA )

# Confusion Matrix | type = "class" => Binary
test_df$pred <- predict(fit.allp, newdata = df.test, type = "class")
(conf_matrix_base <- table(test_df$pred, test_df$actual)) 

# Probability of Predicting "0" Correctly
sensitivity(conf_matrix_base)

# Probability of Predicting "1" correctly
specificity(conf_matrix_base)

# Misclassification Rate
(mis.rate <- conf_matrix_base[1, 2] + 
    conf_matrix_base[2, 1])/sum(conf_matrix_base) 

# Random Forest Approach


# Fit to train data set
fit.rf.ranger <- ranger(df.train$biry ~ ., data = df.train, 
                        importance = 'impurity', mtry = 3)
print(fit.rf.ranger)

# Extract variable importance scores
(v1 <- vi(fit.rf.ranger))
vip(v1)

# Predict response in testing variable 
pred <- predict(fit.rf.ranger, data = df.test)
test_df <- data.frame(actual = df.test$biry, pred = NA)
test_df$pred <- pred$predictions
(conf_matrix_rf <- table(test_df$pred, test_df$actual)) 



# Sensitivity, here  P(0|0), since Positive Class is 0
sensitivity(conf_matrix_rf)

# Specificity, here P(1|1)
specificity(conf_matrix_rf)



# XGBoost

# Transform the predictor matrix using dummy (or indicator or one-hot) encoding 
matrix_predictors.train <- 
  as.matrix(sparse.model.matrix(df.train$biry ~., data = df.train))[, -1]
matrix_predictors.test <- 
  as.matrix(sparse.model.matrix(df.test$biry ~., data = df.test))[, -1]

# Train dataset
pred.train.gbm <- data.matrix(matrix_predictors.train) # predictors only
#convert factor to numeric
df.train.gbm <- as.numeric(as.character(df.train$biry)) 
dtrain <- xgb.DMatrix(data = pred.train.gbm, label = df.train.gbm)
# Test dataset
pred.test.gbm <- data.matrix(matrix_predictors.test) # predictors only
#convert factor to numeric
df.test.gbm <- as.numeric(as.character(df.test$biry))
dtest <- xgb.DMatrix(data = pred.test.gbm, label = df.test.gbm)

# Setup two lists
watchlist <- list(train = dtrain, test = dtest)
param <- list(max_depth = 2, eta = 1, nthread = 2,
              objective = "binary:logistic", eval_metric = "auc")

# Fit model
model.xgb <- xgb.train(param, dtrain, nrounds = 100, watchlist)

# Accuracy of Model


# Predict Testing Data Set
pred.y = predict(model.xgb, pred.test.gbm)
prediction <- as.numeric(pred.y > 0.5)
print(head(prediction))

# Measure prediction accuracy on test data
conf_matrix_gb <- table(test_df$pred, test_df$actual) #confusion matrix<-
#table(bank.data.test.gbm,prediction))
sum(diag(conf_matrix_gb))/sum(conf_matrix_gb)  #accuracy

# Sensitivity, here  P(0|0), since Positive Class is 0
sensitivity(conf_matrix_gb)

# Specificity, here P(1|1)
specificity(conf_matrix_gb)

# Missclassification error rate:
(conf_matrix_gb[1,2] + conf_matrix_gb[2,1])/sum(conf_matrix_gb) 
